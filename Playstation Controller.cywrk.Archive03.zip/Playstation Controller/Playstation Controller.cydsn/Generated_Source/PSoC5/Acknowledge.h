/*******************************************************************************
* File Name: Acknowledge.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Acknowledge_H) /* Pins Acknowledge_H */
#define CY_PINS_Acknowledge_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Acknowledge_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Acknowledge__PORT == 15 && ((Acknowledge__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Acknowledge_Write(uint8 value);
void    Acknowledge_SetDriveMode(uint8 mode);
uint8   Acknowledge_ReadDataReg(void);
uint8   Acknowledge_Read(void);
void    Acknowledge_SetInterruptMode(uint16 position, uint16 mode);
uint8   Acknowledge_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Acknowledge_SetDriveMode() function.
     *  @{
     */
        #define Acknowledge_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Acknowledge_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Acknowledge_DM_RES_UP          PIN_DM_RES_UP
        #define Acknowledge_DM_RES_DWN         PIN_DM_RES_DWN
        #define Acknowledge_DM_OD_LO           PIN_DM_OD_LO
        #define Acknowledge_DM_OD_HI           PIN_DM_OD_HI
        #define Acknowledge_DM_STRONG          PIN_DM_STRONG
        #define Acknowledge_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Acknowledge_MASK               Acknowledge__MASK
#define Acknowledge_SHIFT              Acknowledge__SHIFT
#define Acknowledge_WIDTH              1u

/* Interrupt constants */
#if defined(Acknowledge__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Acknowledge_SetInterruptMode() function.
     *  @{
     */
        #define Acknowledge_INTR_NONE      (uint16)(0x0000u)
        #define Acknowledge_INTR_RISING    (uint16)(0x0001u)
        #define Acknowledge_INTR_FALLING   (uint16)(0x0002u)
        #define Acknowledge_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Acknowledge_INTR_MASK      (0x01u) 
#endif /* (Acknowledge__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Acknowledge_PS                     (* (reg8 *) Acknowledge__PS)
/* Data Register */
#define Acknowledge_DR                     (* (reg8 *) Acknowledge__DR)
/* Port Number */
#define Acknowledge_PRT_NUM                (* (reg8 *) Acknowledge__PRT) 
/* Connect to Analog Globals */                                                  
#define Acknowledge_AG                     (* (reg8 *) Acknowledge__AG)                       
/* Analog MUX bux enable */
#define Acknowledge_AMUX                   (* (reg8 *) Acknowledge__AMUX) 
/* Bidirectional Enable */                                                        
#define Acknowledge_BIE                    (* (reg8 *) Acknowledge__BIE)
/* Bit-mask for Aliased Register Access */
#define Acknowledge_BIT_MASK               (* (reg8 *) Acknowledge__BIT_MASK)
/* Bypass Enable */
#define Acknowledge_BYP                    (* (reg8 *) Acknowledge__BYP)
/* Port wide control signals */                                                   
#define Acknowledge_CTL                    (* (reg8 *) Acknowledge__CTL)
/* Drive Modes */
#define Acknowledge_DM0                    (* (reg8 *) Acknowledge__DM0) 
#define Acknowledge_DM1                    (* (reg8 *) Acknowledge__DM1)
#define Acknowledge_DM2                    (* (reg8 *) Acknowledge__DM2) 
/* Input Buffer Disable Override */
#define Acknowledge_INP_DIS                (* (reg8 *) Acknowledge__INP_DIS)
/* LCD Common or Segment Drive */
#define Acknowledge_LCD_COM_SEG            (* (reg8 *) Acknowledge__LCD_COM_SEG)
/* Enable Segment LCD */
#define Acknowledge_LCD_EN                 (* (reg8 *) Acknowledge__LCD_EN)
/* Slew Rate Control */
#define Acknowledge_SLW                    (* (reg8 *) Acknowledge__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Acknowledge_PRTDSI__CAPS_SEL       (* (reg8 *) Acknowledge__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Acknowledge_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Acknowledge__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Acknowledge_PRTDSI__OE_SEL0        (* (reg8 *) Acknowledge__PRTDSI__OE_SEL0) 
#define Acknowledge_PRTDSI__OE_SEL1        (* (reg8 *) Acknowledge__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Acknowledge_PRTDSI__OUT_SEL0       (* (reg8 *) Acknowledge__PRTDSI__OUT_SEL0) 
#define Acknowledge_PRTDSI__OUT_SEL1       (* (reg8 *) Acknowledge__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Acknowledge_PRTDSI__SYNC_OUT       (* (reg8 *) Acknowledge__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Acknowledge__SIO_CFG)
    #define Acknowledge_SIO_HYST_EN        (* (reg8 *) Acknowledge__SIO_HYST_EN)
    #define Acknowledge_SIO_REG_HIFREQ     (* (reg8 *) Acknowledge__SIO_REG_HIFREQ)
    #define Acknowledge_SIO_CFG            (* (reg8 *) Acknowledge__SIO_CFG)
    #define Acknowledge_SIO_DIFF           (* (reg8 *) Acknowledge__SIO_DIFF)
#endif /* (Acknowledge__SIO_CFG) */

/* Interrupt Registers */
#if defined(Acknowledge__INTSTAT)
    #define Acknowledge_INTSTAT            (* (reg8 *) Acknowledge__INTSTAT)
    #define Acknowledge_SNAP               (* (reg8 *) Acknowledge__SNAP)
    
	#define Acknowledge_0_INTTYPE_REG 		(* (reg8 *) Acknowledge__0__INTTYPE)
#endif /* (Acknowledge__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Acknowledge_H */


/* [] END OF FILE */
