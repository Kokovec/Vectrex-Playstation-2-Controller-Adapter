/*******************************************************************************
* File Name: SPIS_Vectrex_PM.c
* Version 2.70
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIS_Vectrex_PVT.h"

static SPIS_Vectrex_BACKUP_STRUCT SPIS_Vectrex_backup = 
{
    SPIS_Vectrex_DISABLED,
    SPIS_Vectrex_BITCTR_INIT,
};


/*******************************************************************************
* Function Name: SPIS_Vectrex_SaveConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_Vectrex_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_RestoreConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_Vectrex_RestoreConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_Sleep
********************************************************************************
*
* Summary:
*  Prepare SPI Slave Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_Vectrex_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_Vectrex_Sleep(void) 
{
    /* Save components enable state */
    if ((SPIS_Vectrex_TX_STATUS_ACTL_REG & SPIS_Vectrex_INT_ENABLE) != 0u)
    {
        SPIS_Vectrex_backup.enableState = 1u;
    }
    else /* Components block is disabled */
    {
        SPIS_Vectrex_backup.enableState = 0u;
    }

    SPIS_Vectrex_Stop();

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_Wakeup
********************************************************************************
*
* Summary:
*  Prepare SPIM Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_Vectrex_backup - used when non-retention registers are restored.
*  SPIS_Vectrex_txBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_txBufferRead - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_rxBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_rxBufferRead - modified every function call - resets to
*  zero.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_Vectrex_Wakeup(void) 
{
    #if (SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED)
        SPIS_Vectrex_txBufferFull = 0u;
        SPIS_Vectrex_txBufferRead = 0u;
        SPIS_Vectrex_txBufferWrite = 0u;
    #endif /* SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED */

    #if (SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED)
        SPIS_Vectrex_rxBufferFull = 0u;
        SPIS_Vectrex_rxBufferRead = 0u;
        SPIS_Vectrex_rxBufferWrite = 0u;
    #endif /* SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED */

    SPIS_Vectrex_ClearFIFO();

    /* Restore components block enable state */
    if (SPIS_Vectrex_backup.enableState != 0u)
    {
         /* Components block was enabled */
         SPIS_Vectrex_Enable();
    } /* Do nothing if components block was disabled */
}


/* [] END OF FILE */
