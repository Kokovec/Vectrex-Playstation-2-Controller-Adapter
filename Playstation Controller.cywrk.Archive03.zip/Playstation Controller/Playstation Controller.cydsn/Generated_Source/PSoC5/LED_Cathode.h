/*******************************************************************************
* File Name: LED_Cathode.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LED_Cathode_H) /* Pins LED_Cathode_H */
#define CY_PINS_LED_Cathode_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LED_Cathode_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 LED_Cathode__PORT == 15 && ((LED_Cathode__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    LED_Cathode_Write(uint8 value);
void    LED_Cathode_SetDriveMode(uint8 mode);
uint8   LED_Cathode_ReadDataReg(void);
uint8   LED_Cathode_Read(void);
void    LED_Cathode_SetInterruptMode(uint16 position, uint16 mode);
uint8   LED_Cathode_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the LED_Cathode_SetDriveMode() function.
     *  @{
     */
        #define LED_Cathode_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define LED_Cathode_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define LED_Cathode_DM_RES_UP          PIN_DM_RES_UP
        #define LED_Cathode_DM_RES_DWN         PIN_DM_RES_DWN
        #define LED_Cathode_DM_OD_LO           PIN_DM_OD_LO
        #define LED_Cathode_DM_OD_HI           PIN_DM_OD_HI
        #define LED_Cathode_DM_STRONG          PIN_DM_STRONG
        #define LED_Cathode_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define LED_Cathode_MASK               LED_Cathode__MASK
#define LED_Cathode_SHIFT              LED_Cathode__SHIFT
#define LED_Cathode_WIDTH              1u

/* Interrupt constants */
#if defined(LED_Cathode__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in LED_Cathode_SetInterruptMode() function.
     *  @{
     */
        #define LED_Cathode_INTR_NONE      (uint16)(0x0000u)
        #define LED_Cathode_INTR_RISING    (uint16)(0x0001u)
        #define LED_Cathode_INTR_FALLING   (uint16)(0x0002u)
        #define LED_Cathode_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define LED_Cathode_INTR_MASK      (0x01u) 
#endif /* (LED_Cathode__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LED_Cathode_PS                     (* (reg8 *) LED_Cathode__PS)
/* Data Register */
#define LED_Cathode_DR                     (* (reg8 *) LED_Cathode__DR)
/* Port Number */
#define LED_Cathode_PRT_NUM                (* (reg8 *) LED_Cathode__PRT) 
/* Connect to Analog Globals */                                                  
#define LED_Cathode_AG                     (* (reg8 *) LED_Cathode__AG)                       
/* Analog MUX bux enable */
#define LED_Cathode_AMUX                   (* (reg8 *) LED_Cathode__AMUX) 
/* Bidirectional Enable */                                                        
#define LED_Cathode_BIE                    (* (reg8 *) LED_Cathode__BIE)
/* Bit-mask for Aliased Register Access */
#define LED_Cathode_BIT_MASK               (* (reg8 *) LED_Cathode__BIT_MASK)
/* Bypass Enable */
#define LED_Cathode_BYP                    (* (reg8 *) LED_Cathode__BYP)
/* Port wide control signals */                                                   
#define LED_Cathode_CTL                    (* (reg8 *) LED_Cathode__CTL)
/* Drive Modes */
#define LED_Cathode_DM0                    (* (reg8 *) LED_Cathode__DM0) 
#define LED_Cathode_DM1                    (* (reg8 *) LED_Cathode__DM1)
#define LED_Cathode_DM2                    (* (reg8 *) LED_Cathode__DM2) 
/* Input Buffer Disable Override */
#define LED_Cathode_INP_DIS                (* (reg8 *) LED_Cathode__INP_DIS)
/* LCD Common or Segment Drive */
#define LED_Cathode_LCD_COM_SEG            (* (reg8 *) LED_Cathode__LCD_COM_SEG)
/* Enable Segment LCD */
#define LED_Cathode_LCD_EN                 (* (reg8 *) LED_Cathode__LCD_EN)
/* Slew Rate Control */
#define LED_Cathode_SLW                    (* (reg8 *) LED_Cathode__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LED_Cathode_PRTDSI__CAPS_SEL       (* (reg8 *) LED_Cathode__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LED_Cathode_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LED_Cathode__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LED_Cathode_PRTDSI__OE_SEL0        (* (reg8 *) LED_Cathode__PRTDSI__OE_SEL0) 
#define LED_Cathode_PRTDSI__OE_SEL1        (* (reg8 *) LED_Cathode__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LED_Cathode_PRTDSI__OUT_SEL0       (* (reg8 *) LED_Cathode__PRTDSI__OUT_SEL0) 
#define LED_Cathode_PRTDSI__OUT_SEL1       (* (reg8 *) LED_Cathode__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LED_Cathode_PRTDSI__SYNC_OUT       (* (reg8 *) LED_Cathode__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(LED_Cathode__SIO_CFG)
    #define LED_Cathode_SIO_HYST_EN        (* (reg8 *) LED_Cathode__SIO_HYST_EN)
    #define LED_Cathode_SIO_REG_HIFREQ     (* (reg8 *) LED_Cathode__SIO_REG_HIFREQ)
    #define LED_Cathode_SIO_CFG            (* (reg8 *) LED_Cathode__SIO_CFG)
    #define LED_Cathode_SIO_DIFF           (* (reg8 *) LED_Cathode__SIO_DIFF)
#endif /* (LED_Cathode__SIO_CFG) */

/* Interrupt Registers */
#if defined(LED_Cathode__INTSTAT)
    #define LED_Cathode_INTSTAT            (* (reg8 *) LED_Cathode__INTSTAT)
    #define LED_Cathode_SNAP               (* (reg8 *) LED_Cathode__SNAP)
    
	#define LED_Cathode_0_INTTYPE_REG 		(* (reg8 *) LED_Cathode__0__INTTYPE)
#endif /* (LED_Cathode__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_LED_Cathode_H */


/* [] END OF FILE */
