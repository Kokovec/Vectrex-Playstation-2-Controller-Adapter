/*******************************************************************************
* File Name: Counter_Ack_PM.c  
* Version 2.40
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "Counter_Ack.h"

static Counter_Ack_backupStruct Counter_Ack_backup;


/*******************************************************************************
* Function Name: Counter_Ack_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_Ack_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Counter_Ack_SaveConfig(void) 
{
    #if (!Counter_Ack_UsingFixedFunction)

        Counter_Ack_backup.CounterUdb = Counter_Ack_ReadCounter();

        #if (CY_UDB_V0)
            Counter_Ack_backup.CounterPeriod = Counter_Ack_ReadPeriod();
            Counter_Ack_backup.CompareValue = Counter_Ack_ReadCompare();
            Counter_Ack_backup.InterruptMaskValue = Counter_Ack_STATUS_MASK;
        #endif /* CY_UDB_V0 */

        #if(!Counter_Ack_ControlRegRemoved)
            Counter_Ack_backup.CounterControlRegister = Counter_Ack_ReadControlRegister();
        #endif /* (!Counter_Ack_ControlRegRemoved) */

    #endif /* (!Counter_Ack_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Counter_Ack_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_Ack_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Counter_Ack_RestoreConfig(void) 
{      
    #if (!Counter_Ack_UsingFixedFunction)

        #if (CY_UDB_V0)
            uint8 Counter_Ack_interruptState;
        #endif  /* (CY_UDB_V0) */

       Counter_Ack_WriteCounter(Counter_Ack_backup.CounterUdb);

        #if (CY_UDB_V0)
            Counter_Ack_WritePeriod(Counter_Ack_backup.CounterPeriod);
            Counter_Ack_WriteCompare(Counter_Ack_backup.CompareValue);

            Counter_Ack_interruptState = CyEnterCriticalSection();
            Counter_Ack_STATUS_AUX_CTRL |= Counter_Ack_STATUS_ACTL_INT_EN_MASK;
            CyExitCriticalSection(Counter_Ack_interruptState);

            Counter_Ack_STATUS_MASK = Counter_Ack_backup.InterruptMaskValue;
        #endif  /* (CY_UDB_V0) */

        #if(!Counter_Ack_ControlRegRemoved)
            Counter_Ack_WriteControlRegister(Counter_Ack_backup.CounterControlRegister);
        #endif /* (!Counter_Ack_ControlRegRemoved) */

    #endif /* (!Counter_Ack_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Counter_Ack_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_Ack_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Counter_Ack_Sleep(void) 
{
    #if(!Counter_Ack_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Counter_Ack_CTRL_ENABLE == (Counter_Ack_CONTROL & Counter_Ack_CTRL_ENABLE))
        {
            /* Counter is enabled */
            Counter_Ack_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            Counter_Ack_backup.CounterEnableState = 0u;
        }
    #else
        Counter_Ack_backup.CounterEnableState = 1u;
        if(Counter_Ack_backup.CounterEnableState != 0u)
        {
            Counter_Ack_backup.CounterEnableState = 0u;
        }
    #endif /* (!Counter_Ack_ControlRegRemoved) */
    
    Counter_Ack_Stop();
    Counter_Ack_SaveConfig();
}


/*******************************************************************************
* Function Name: Counter_Ack_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_Ack_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Counter_Ack_Wakeup(void) 
{
    Counter_Ack_RestoreConfig();
    #if(!Counter_Ack_ControlRegRemoved)
        if(Counter_Ack_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            Counter_Ack_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!Counter_Ack_ControlRegRemoved) */
    
}


/* [] END OF FILE */
