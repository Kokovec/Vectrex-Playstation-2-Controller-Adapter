/*******************************************************************************
* File Name: SPIS_Vectrex_INT.c
* Version 2.70
*
* Description:
*  This file provides all Interrupt Service Routine (ISR) for the SPI Slave
*  component.
*
* Note:
*  None.
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIS_Vectrex_PVT.h"


/* User code required at start of ISR */
/* `#START SPIS_Vectrex_ISR_START_DEF` */

/* `#END` */


/*******************************************************************************
* Function Name: SPIS_Vectrex_TX_ISR
*
* Summary:
*  Interrupt Service Routine for TX portion of the SPI Slave.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  SPIS_Vectrex_txBufferWrite - used for the account of the bytes which
*  have been written down in the TX software buffer.
*  SPIS_Vectrex_txBufferRead - used for the account of the bytes which
*  have been read from the TX software buffer, modified when exist data to
*  sending and FIFO Not Full.
*  SPIS_Vectrex_txBuffer[SPIS_Vectrex_TX_BUFFER_SIZE] - used to store
*  data to sending.
*  All described above Global variables are used when Software Buffer is used.
*
*******************************************************************************/
CY_ISR(SPIS_Vectrex_TX_ISR)
{

    #if(SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED)
        uint8 tmpStatus;
    #endif /* (SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED) */

    #ifdef SPIS_Vectrex_TX_ISR_ENTRY_CALLBACK
        SPIS_Vectrex_TX_ISR_EntryCallback();
    #endif /* SPIS_Vectrex_TX_ISR_ENTRY_CALLBACK */

    /* User code required at start of ISR */
    /* `#START SPIS_Vectrex_ISR_TX_START` */

    /* `#END` */

    #if(SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED)
        /* Component interrupt service code */

        /* See if TX data buffer is not empty and there is space in TX FIFO */
        while(SPIS_Vectrex_txBufferRead != SPIS_Vectrex_txBufferWrite)
        {
            tmpStatus = SPIS_Vectrex_GET_STATUS_TX(SPIS_Vectrex_swStatusTx);
            SPIS_Vectrex_swStatusTx = tmpStatus;

            if ((SPIS_Vectrex_swStatusTx & SPIS_Vectrex_STS_TX_FIFO_NOT_FULL) != 0u)
            {
                if(SPIS_Vectrex_txBufferFull == 0u)
                {
                   SPIS_Vectrex_txBufferRead++;

                    if(SPIS_Vectrex_txBufferRead >= SPIS_Vectrex_TX_BUFFER_SIZE)
                    {
                        SPIS_Vectrex_txBufferRead = 0u;
                    }
                }
                else
                {
                    SPIS_Vectrex_txBufferFull = 0u;
                }

                /* Put data element into the TX FIFO */
                CY_SET_REG8(SPIS_Vectrex_TXDATA_PTR, 
                                             SPIS_Vectrex_txBuffer[SPIS_Vectrex_txBufferRead]);
            }
            else
            {
                break;
            }
        }

        /* If Buffer is empty then disable TX FIFO status interrupt until there is data in the buffer */
        if(SPIS_Vectrex_txBufferRead == SPIS_Vectrex_txBufferWrite)
        {
            SPIS_Vectrex_TX_STATUS_MASK_REG &= ((uint8)~SPIS_Vectrex_STS_TX_FIFO_NOT_FULL);
        }

    #endif /* SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED */

    /* User code required at end of ISR (Optional) */
    /* `#START SPIS_Vectrex_ISR_TX_END` */

    /* `#END` */
    
    #ifdef SPIS_Vectrex_TX_ISR_EXIT_CALLBACK
        SPIS_Vectrex_TX_ISR_ExitCallback();
    #endif /* SPIS_Vectrex_TX_ISR_EXIT_CALLBACK */
   }


/*******************************************************************************
* Function Name: SPIS_Vectrex_RX_ISR
*
* Summary:
*  Interrupt Service Routine for RX portion of the SPI Slave.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  SPIS_Vectrex_rxBufferWrite - used for the account of the bytes which
*  have been written down in the RX software buffer modified when FIFO contains
*  new data.
*  SPIS_Vectrex_rxBufferRead - used for the account of the bytes which
*  have been read from the RX software buffer, modified when overflow occurred.
*  SPIS_Vectrex_rxBuffer[SPIS_Vectrex_RX_BUFFER_SIZE] - used to store
*  received data, modified when FIFO contains new data.
*  All described above Global variables are used when Software Buffer is used.
*
*******************************************************************************/
CY_ISR(SPIS_Vectrex_RX_ISR)
{
    #if(SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED)
        uint8 tmpStatus;
        uint8 rxData;
    #endif /* (SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED) */

    #ifdef SPIS_Vectrex_RX_ISR_ENTRY_CALLBACK
        SPIS_Vectrex_RX_ISR_EntryCallback();
    #endif /* SPIS_Vectrex_RX_ISR_ENTRY_CALLBACK */

    /* User code required at start of ISR */
    /* `#START SPIS_Vectrex_RX_ISR_START` */

    /* `#END` */
    
    #if(SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED)
        tmpStatus = SPIS_Vectrex_GET_STATUS_RX(SPIS_Vectrex_swStatusRx);
        SPIS_Vectrex_swStatusRx = tmpStatus;
        /* See if RX data FIFO has some data and if it can be moved to the RX Buffer */
        while((SPIS_Vectrex_swStatusRx & SPIS_Vectrex_STS_RX_FIFO_NOT_EMPTY) != 0u)
        {
            rxData = CY_GET_REG8(SPIS_Vectrex_RXDATA_PTR);

            /* Set next pointer. */
            SPIS_Vectrex_rxBufferWrite++;
            if(SPIS_Vectrex_rxBufferWrite >= SPIS_Vectrex_RX_BUFFER_SIZE)
            {
                SPIS_Vectrex_rxBufferWrite = 0u;
            }

            if(SPIS_Vectrex_rxBufferWrite == SPIS_Vectrex_rxBufferRead)
            {
                SPIS_Vectrex_rxBufferRead++;
                if(SPIS_Vectrex_rxBufferRead >= SPIS_Vectrex_RX_BUFFER_SIZE)
                {
                    SPIS_Vectrex_rxBufferRead = 0u;
                }
                SPIS_Vectrex_rxBufferFull = 1u;
            }

            /* Move data from the FIFO to the Buffer */
            SPIS_Vectrex_rxBuffer[SPIS_Vectrex_rxBufferWrite] = rxData;

            tmpStatus = SPIS_Vectrex_GET_STATUS_RX(SPIS_Vectrex_swStatusRx);
            SPIS_Vectrex_swStatusRx = tmpStatus;
        }
    #endif /* SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED */

    /* User code required at end of ISR (Optional) */
    /* `#START SPIS_Vectrex_RX_ISR_END` */

    /* `#END` */

    #ifdef SPIS_Vectrex_RX_ISR_EXIT_CALLBACK
        SPIS_Vectrex_RX_ISR_ExitCallback();
    #endif /* SPIS_Vectrex_RX_ISR_EXIT_CALLBACK */
}

/* [] END OF FILE */
