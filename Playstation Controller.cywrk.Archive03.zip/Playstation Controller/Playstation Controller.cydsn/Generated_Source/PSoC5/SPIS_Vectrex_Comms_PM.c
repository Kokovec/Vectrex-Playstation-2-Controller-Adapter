/*******************************************************************************
* File Name: SPIS_Vectrex_Comms_PM.c
* Version 2.70
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIS_Vectrex_Comms_PVT.h"

static SPIS_Vectrex_Comms_BACKUP_STRUCT SPIS_Vectrex_Comms_backup = 
{
    SPIS_Vectrex_Comms_DISABLED,
    SPIS_Vectrex_Comms_BITCTR_INIT,
};


/*******************************************************************************
* Function Name: SPIS_Vectrex_Comms_SaveConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_Vectrex_Comms_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_Comms_RestoreConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_Vectrex_Comms_RestoreConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_Comms_Sleep
********************************************************************************
*
* Summary:
*  Prepare SPI Slave Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_Vectrex_Comms_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_Vectrex_Comms_Sleep(void) 
{
    /* Save components enable state */
    if ((SPIS_Vectrex_Comms_TX_STATUS_ACTL_REG & SPIS_Vectrex_Comms_INT_ENABLE) != 0u)
    {
        SPIS_Vectrex_Comms_backup.enableState = 1u;
    }
    else /* Components block is disabled */
    {
        SPIS_Vectrex_Comms_backup.enableState = 0u;
    }

    SPIS_Vectrex_Comms_Stop();

}


/*******************************************************************************
* Function Name: SPIS_Vectrex_Comms_Wakeup
********************************************************************************
*
* Summary:
*  Prepare SPIM Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_Vectrex_Comms_backup - used when non-retention registers are restored.
*  SPIS_Vectrex_Comms_txBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_Comms_txBufferRead - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_Comms_rxBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_Vectrex_Comms_rxBufferRead - modified every function call - resets to
*  zero.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_Vectrex_Comms_Wakeup(void) 
{
    #if (SPIS_Vectrex_Comms_TX_SOFTWARE_BUF_ENABLED)
        SPIS_Vectrex_Comms_txBufferFull = 0u;
        SPIS_Vectrex_Comms_txBufferRead = 0u;
        SPIS_Vectrex_Comms_txBufferWrite = 0u;
    #endif /* SPIS_Vectrex_Comms_TX_SOFTWARE_BUF_ENABLED */

    #if (SPIS_Vectrex_Comms_RX_SOFTWARE_BUF_ENABLED)
        SPIS_Vectrex_Comms_rxBufferFull = 0u;
        SPIS_Vectrex_Comms_rxBufferRead = 0u;
        SPIS_Vectrex_Comms_rxBufferWrite = 0u;
    #endif /* SPIS_Vectrex_Comms_RX_SOFTWARE_BUF_ENABLED */

    SPIS_Vectrex_Comms_ClearFIFO();

    /* Restore components block enable state */
    if (SPIS_Vectrex_Comms_backup.enableState != 0u)
    {
         /* Components block was enabled */
         SPIS_Vectrex_Comms_Enable();
    } /* Do nothing if components block was disabled */
}


/* [] END OF FILE */
