/*******************************************************************************
* File Name: Command.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Command_H) /* Pins Command_H */
#define CY_PINS_Command_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Command_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Command__PORT == 15 && ((Command__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Command_Write(uint8 value);
void    Command_SetDriveMode(uint8 mode);
uint8   Command_ReadDataReg(void);
uint8   Command_Read(void);
void    Command_SetInterruptMode(uint16 position, uint16 mode);
uint8   Command_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Command_SetDriveMode() function.
     *  @{
     */
        #define Command_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Command_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Command_DM_RES_UP          PIN_DM_RES_UP
        #define Command_DM_RES_DWN         PIN_DM_RES_DWN
        #define Command_DM_OD_LO           PIN_DM_OD_LO
        #define Command_DM_OD_HI           PIN_DM_OD_HI
        #define Command_DM_STRONG          PIN_DM_STRONG
        #define Command_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Command_MASK               Command__MASK
#define Command_SHIFT              Command__SHIFT
#define Command_WIDTH              1u

/* Interrupt constants */
#if defined(Command__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Command_SetInterruptMode() function.
     *  @{
     */
        #define Command_INTR_NONE      (uint16)(0x0000u)
        #define Command_INTR_RISING    (uint16)(0x0001u)
        #define Command_INTR_FALLING   (uint16)(0x0002u)
        #define Command_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Command_INTR_MASK      (0x01u) 
#endif /* (Command__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Command_PS                     (* (reg8 *) Command__PS)
/* Data Register */
#define Command_DR                     (* (reg8 *) Command__DR)
/* Port Number */
#define Command_PRT_NUM                (* (reg8 *) Command__PRT) 
/* Connect to Analog Globals */                                                  
#define Command_AG                     (* (reg8 *) Command__AG)                       
/* Analog MUX bux enable */
#define Command_AMUX                   (* (reg8 *) Command__AMUX) 
/* Bidirectional Enable */                                                        
#define Command_BIE                    (* (reg8 *) Command__BIE)
/* Bit-mask for Aliased Register Access */
#define Command_BIT_MASK               (* (reg8 *) Command__BIT_MASK)
/* Bypass Enable */
#define Command_BYP                    (* (reg8 *) Command__BYP)
/* Port wide control signals */                                                   
#define Command_CTL                    (* (reg8 *) Command__CTL)
/* Drive Modes */
#define Command_DM0                    (* (reg8 *) Command__DM0) 
#define Command_DM1                    (* (reg8 *) Command__DM1)
#define Command_DM2                    (* (reg8 *) Command__DM2) 
/* Input Buffer Disable Override */
#define Command_INP_DIS                (* (reg8 *) Command__INP_DIS)
/* LCD Common or Segment Drive */
#define Command_LCD_COM_SEG            (* (reg8 *) Command__LCD_COM_SEG)
/* Enable Segment LCD */
#define Command_LCD_EN                 (* (reg8 *) Command__LCD_EN)
/* Slew Rate Control */
#define Command_SLW                    (* (reg8 *) Command__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Command_PRTDSI__CAPS_SEL       (* (reg8 *) Command__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Command_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Command__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Command_PRTDSI__OE_SEL0        (* (reg8 *) Command__PRTDSI__OE_SEL0) 
#define Command_PRTDSI__OE_SEL1        (* (reg8 *) Command__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Command_PRTDSI__OUT_SEL0       (* (reg8 *) Command__PRTDSI__OUT_SEL0) 
#define Command_PRTDSI__OUT_SEL1       (* (reg8 *) Command__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Command_PRTDSI__SYNC_OUT       (* (reg8 *) Command__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Command__SIO_CFG)
    #define Command_SIO_HYST_EN        (* (reg8 *) Command__SIO_HYST_EN)
    #define Command_SIO_REG_HIFREQ     (* (reg8 *) Command__SIO_REG_HIFREQ)
    #define Command_SIO_CFG            (* (reg8 *) Command__SIO_CFG)
    #define Command_SIO_DIFF           (* (reg8 *) Command__SIO_DIFF)
#endif /* (Command__SIO_CFG) */

/* Interrupt Registers */
#if defined(Command__INTSTAT)
    #define Command_INTSTAT            (* (reg8 *) Command__INTSTAT)
    #define Command_SNAP               (* (reg8 *) Command__SNAP)
    
	#define Command_0_INTTYPE_REG 		(* (reg8 *) Command__0__INTTYPE)
#endif /* (Command__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Command_H */


/* [] END OF FILE */
