/*******************************************************************************
* File Name: .h
* Version 2.70
*
* Description:
*  This private header file contains internal definitions for the SPIS
*  component. Do not use these definitions directly in your application.
*
* Note:
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SPIS_PVT_SPIS_Vectrex_H)
#define CY_SPIS_PVT_SPIS_Vectrex_H

#include "SPIS_Vectrex.h"


/**********************************
*   Functions with external linkage
**********************************/


/**********************************
*   Variables with external linkage
**********************************/
extern volatile uint8 SPIS_Vectrex_swStatusTx;
extern volatile uint8 SPIS_Vectrex_swStatusRx;

#if (SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED)

    extern volatile uint8 SPIS_Vectrex_rxBuffer[SPIS_Vectrex_RX_BUFFER_SIZE];
    extern volatile uint8 SPIS_Vectrex_rxBufferRead;
    extern volatile uint8 SPIS_Vectrex_rxBufferWrite;
    extern volatile uint8 SPIS_Vectrex_rxBufferFull;

#endif /* SPIS_Vectrex_RX_SOFTWARE_BUF_ENABLED */

#if (SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED)

    extern volatile uint8 SPIS_Vectrex_txBuffer[SPIS_Vectrex_TX_BUFFER_SIZE];
    extern volatile uint8 SPIS_Vectrex_txBufferRead;
    extern volatile uint8 SPIS_Vectrex_txBufferWrite;
    extern volatile uint8 SPIS_Vectrex_txBufferFull;

#endif /* SPIS_Vectrex_TX_SOFTWARE_BUF_ENABLED */

#endif /* CY_SPIS_PVT_SPIS_Vectrex_H */


/* [] END OF FILE */
