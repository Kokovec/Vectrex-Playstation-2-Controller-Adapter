/*******************************************************************************
* File Name: Digi_Pot_CS_Joy_2_Pot_Y.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Digi_Pot_CS_Joy_2_Pot_Y_H) /* Pins Digi_Pot_CS_Joy_2_Pot_Y_H */
#define CY_PINS_Digi_Pot_CS_Joy_2_Pot_Y_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Digi_Pot_CS_Joy_2_Pot_Y_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Digi_Pot_CS_Joy_2_Pot_Y__PORT == 15 && ((Digi_Pot_CS_Joy_2_Pot_Y__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Digi_Pot_CS_Joy_2_Pot_Y_Write(uint8 value);
void    Digi_Pot_CS_Joy_2_Pot_Y_SetDriveMode(uint8 mode);
uint8   Digi_Pot_CS_Joy_2_Pot_Y_ReadDataReg(void);
uint8   Digi_Pot_CS_Joy_2_Pot_Y_Read(void);
void    Digi_Pot_CS_Joy_2_Pot_Y_SetInterruptMode(uint16 position, uint16 mode);
uint8   Digi_Pot_CS_Joy_2_Pot_Y_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Digi_Pot_CS_Joy_2_Pot_Y_SetDriveMode() function.
     *  @{
     */
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_RES_UP          PIN_DM_RES_UP
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_RES_DWN         PIN_DM_RES_DWN
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_OD_LO           PIN_DM_OD_LO
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_OD_HI           PIN_DM_OD_HI
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_STRONG          PIN_DM_STRONG
        #define Digi_Pot_CS_Joy_2_Pot_Y_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Digi_Pot_CS_Joy_2_Pot_Y_MASK               Digi_Pot_CS_Joy_2_Pot_Y__MASK
#define Digi_Pot_CS_Joy_2_Pot_Y_SHIFT              Digi_Pot_CS_Joy_2_Pot_Y__SHIFT
#define Digi_Pot_CS_Joy_2_Pot_Y_WIDTH              1u

/* Interrupt constants */
#if defined(Digi_Pot_CS_Joy_2_Pot_Y__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Digi_Pot_CS_Joy_2_Pot_Y_SetInterruptMode() function.
     *  @{
     */
        #define Digi_Pot_CS_Joy_2_Pot_Y_INTR_NONE      (uint16)(0x0000u)
        #define Digi_Pot_CS_Joy_2_Pot_Y_INTR_RISING    (uint16)(0x0001u)
        #define Digi_Pot_CS_Joy_2_Pot_Y_INTR_FALLING   (uint16)(0x0002u)
        #define Digi_Pot_CS_Joy_2_Pot_Y_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Digi_Pot_CS_Joy_2_Pot_Y_INTR_MASK      (0x01u) 
#endif /* (Digi_Pot_CS_Joy_2_Pot_Y__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Digi_Pot_CS_Joy_2_Pot_Y_PS                     (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PS)
/* Data Register */
#define Digi_Pot_CS_Joy_2_Pot_Y_DR                     (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__DR)
/* Port Number */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRT_NUM                (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRT) 
/* Connect to Analog Globals */                                                  
#define Digi_Pot_CS_Joy_2_Pot_Y_AG                     (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__AG)                       
/* Analog MUX bux enable */
#define Digi_Pot_CS_Joy_2_Pot_Y_AMUX                   (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__AMUX) 
/* Bidirectional Enable */                                                        
#define Digi_Pot_CS_Joy_2_Pot_Y_BIE                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__BIE)
/* Bit-mask for Aliased Register Access */
#define Digi_Pot_CS_Joy_2_Pot_Y_BIT_MASK               (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__BIT_MASK)
/* Bypass Enable */
#define Digi_Pot_CS_Joy_2_Pot_Y_BYP                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__BYP)
/* Port wide control signals */                                                   
#define Digi_Pot_CS_Joy_2_Pot_Y_CTL                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__CTL)
/* Drive Modes */
#define Digi_Pot_CS_Joy_2_Pot_Y_DM0                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__DM0) 
#define Digi_Pot_CS_Joy_2_Pot_Y_DM1                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__DM1)
#define Digi_Pot_CS_Joy_2_Pot_Y_DM2                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__DM2) 
/* Input Buffer Disable Override */
#define Digi_Pot_CS_Joy_2_Pot_Y_INP_DIS                (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__INP_DIS)
/* LCD Common or Segment Drive */
#define Digi_Pot_CS_Joy_2_Pot_Y_LCD_COM_SEG            (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__LCD_COM_SEG)
/* Enable Segment LCD */
#define Digi_Pot_CS_Joy_2_Pot_Y_LCD_EN                 (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__LCD_EN)
/* Slew Rate Control */
#define Digi_Pot_CS_Joy_2_Pot_Y_SLW                    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__CAPS_SEL       (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__OE_SEL0        (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__OE_SEL0) 
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__OE_SEL1        (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__OUT_SEL0       (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__OUT_SEL0) 
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__OUT_SEL1       (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Digi_Pot_CS_Joy_2_Pot_Y_PRTDSI__SYNC_OUT       (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Digi_Pot_CS_Joy_2_Pot_Y__SIO_CFG)
    #define Digi_Pot_CS_Joy_2_Pot_Y_SIO_HYST_EN        (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SIO_HYST_EN)
    #define Digi_Pot_CS_Joy_2_Pot_Y_SIO_REG_HIFREQ     (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SIO_REG_HIFREQ)
    #define Digi_Pot_CS_Joy_2_Pot_Y_SIO_CFG            (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SIO_CFG)
    #define Digi_Pot_CS_Joy_2_Pot_Y_SIO_DIFF           (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SIO_DIFF)
#endif /* (Digi_Pot_CS_Joy_2_Pot_Y__SIO_CFG) */

/* Interrupt Registers */
#if defined(Digi_Pot_CS_Joy_2_Pot_Y__INTSTAT)
    #define Digi_Pot_CS_Joy_2_Pot_Y_INTSTAT            (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__INTSTAT)
    #define Digi_Pot_CS_Joy_2_Pot_Y_SNAP               (* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__SNAP)
    
	#define Digi_Pot_CS_Joy_2_Pot_Y_0_INTTYPE_REG 		(* (reg8 *) Digi_Pot_CS_Joy_2_Pot_Y__0__INTTYPE)
#endif /* (Digi_Pot_CS_Joy_2_Pot_Y__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Digi_Pot_CS_Joy_2_Pot_Y_H */


/* [] END OF FILE */
