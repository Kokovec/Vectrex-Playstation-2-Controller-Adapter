/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <Defines.h>

void Write_To_SPI(uint8 tx_data);
void Write_To_SPI_Pot(uint8 tx_data);
void Write_To_SPI_Pot_Joy_2(uint8 tx_data);
void Handle_Vectrex_Data();
uint8 WaitForAck();
void WaitForWrite();
void WaitForRxready();
uint8 MinMax(uint8 x);
uint8 Get_PS2_Data();
void Handle_Buttons();
void Get_Buttons();
void Program_Buttons();
void Handle_Sticks(uint8 mode);
void Setup_Controller(uint8);
void ZeroPots();
void WaitForRxready_Vectrex();
void Reset_Buttons();
// void Flash_LED(uint8 count, uint8 speed);

struct controller
{
    uint8 Button_1;
    uint8 Button_2;
    uint8 Joy_Right_LR;
    uint8 Joy_Right_UD;
    uint8 Joy_Left_LR;
    uint8 Joy_left_UD;
};
struct controller controller;

struct Joy_Buttons
{
    uint16 Button_1;
    uint16 Button_2;
    uint16 Button_3;
    uint16 Button_4;
    uint16 Button_5;
    uint16 Button_6;
    uint16 Button_7;
    uint16 Button_8;
};
struct Joy_Buttons Joy_Buttons;

const uint16 LUT_Buttons[] = {Pad_Up,Pad_Right,Pad_Down,Pad_Left,
                        L2,R2,L1,R1,Triangle,Circle,X,Square};
    
uint8 Ack_Timeout = 0;          // used by isr; 1 = interrupt
uint8 Timeout_SPIS = 0;         // used by isr_cmp; 1 = interrupt
uint8 Flash_Count = 0;          // used by isr; counts interrupt cycles
uint16 Button_State = 0;        // State of all contoller buttons
uint8 Joy_Mode = 0;             // 0=none, 1=joy 1, 2=joy 2, 3=robotron
uint8 Button_Program_State;     // 0=not pgm mode, 1=program mode
uint8 VecFever_Mode = 0;        // 1 = VecFever mode
uint8 VecFever_Buffer[20];        // Command buffer
uint8 VecFever_Command_Response = 0;    // Keeps last command in case VecFever wants it
uint8 Buffer_Counter= 0;           // Points to next command in buffer
uint8 Lost_Comms = 1;           //0= good, 1= lost comms


int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    SPIM_Start();
    SPIM_Vectrex_Joy_Start();
    SPIM_Vectrex_Joy_2_Start();
    SPIS_Vectrex_Start();
    EEPROM_1_Start();
    Counter_SPIS_Start();
    Control_Reg_Joy2_Buttons_Enable_Write(1);   // Joy2 Buttons to output
    // UART_1_Start();
    isr_Ack_Start();
    //isr_cmp_Start();

    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    
    // Set up initial button states
    Reset_Buttons();
    
    // Zero out the Joy Pots
    ZeroPots();
   
    ;CyDelay(1000);
    //LED_Cathode_Write(0);
    //LED_Anode_Write(1);     // Set LED to GREEN
    
    // Set up the status LEDs
    LED_1_GREEN_Write(0);
    LED_2_GREEN_Write(0);
    LED_1_RED_Write(0);
    LED_2_RED_Write(0);
              
    //Setup_Controller(0x01);     //set analog mode
    
    // Deselect Digi Pots
    Control_Reg_Pot_CS_Write(3);
    Control_Reg_Pot_CS_Joy_2_Write(3);
    // Clear SPIS buffer
    SPIS_Vectrex_ClearRxBuffer();
    SPIS_Vectrex_ClearTxBuffer();
    SPIS_Vectrex_ClearFIFO();
    
    for(;;)
    {
        
        if(Lost_Comms == 1)
        {
            CyDelay(1000);
            Setup_Controller(0x01);     //set analog mode
            Setup_Controller(0x01);     //set analog mode
        }
        else
        {
            // Check for VecFever mode
            if(Pin_VecFever_Test_In_Read() == 0)
            {
                Control_Reg_PSOC_LED_Select_Write(1);
                Control_Reg_Joy2_Buttons_Enable_Write(0);
                // Check if data in buffer
                if(SPIS_Vectrex_GetRxBufferSize())
                {
                    // Add code here
                    Handle_Vectrex_Data(LUT_Buttons, sizeof(LUT_Buttons)/sizeof(LUT_Buttons[0]));
                }
            }
            else
            {
                Control_Reg_PSOC_LED_Write(1);  // PSOC LED Green
                Control_Reg_PSOC_LED_Select_Write(0);
            }
            Handle_Sticks(0);
            Get_Buttons();
            Handle_Buttons();
            //UART_1_PutChar(Button_State >> 8);
            //UART_1_PutChar(Button_State);
        }
    }
}


void Write_To_SPI(uint8 tx_data)
{
    uint8 temp;
    
    // Clear the TX buffer
    SPIM_ClearTxBuffer();
    // Ensure that previous SPI read is done, or SPI is idle before sending data
    temp = SPIM_ReadTxStatus();
    while(!(temp & (SPIM_STS_SPI_DONE | SPIM_STS_SPI_IDLE)));
    // Send the data
    SPIM_WriteTxData(tx_data);
    // Ensure data is sent before returning from function
    while( ! (SPIM_ReadTxStatus() & SPIM_STS_BYTE_COMPLETE  ) );
}

void Write_To_SPI_Pot(uint8 tx_data)
{
    uint8 temp;
    // Clear the TX buffer
    SPIM_Vectrex_Joy_ClearTxBuffer();
    // Ensure that previous SPI read is done, or SPI is idle before sending data
    temp = SPIM_Vectrex_Joy_ReadTxStatus();
    while(!(temp & (SPIM_Vectrex_Joy_STS_SPI_DONE | SPIM_Vectrex_Joy_STS_SPI_IDLE)));
    // Send the data
    SPIM_Vectrex_Joy_WriteTxData(tx_data);
    // Ensure data is sent before returning from function
    while( ! (SPIM_Vectrex_Joy_ReadTxStatus() & SPIM_Vectrex_Joy_STS_BYTE_COMPLETE  ) );
    CyDelay(1);
}

void Write_To_SPI_Pot_Joy_2(uint8 tx_data)
{
    uint8 temp;

    // Clear the TX buffer
    SPIM_Vectrex_Joy_2_ClearTxBuffer();
    // Ensure that previous SPI read is done, or SPI is idle before sending data
    temp = SPIM_Vectrex_Joy_2_ReadTxStatus();
    while(!(temp & (SPIM_Vectrex_Joy_2_STS_SPI_DONE | SPIM_Vectrex_Joy_2_STS_SPI_IDLE)));
    // Send the data
    SPIM_Vectrex_Joy_2_WriteTxData(tx_data);
    // Ensure data is sent before returning from function
    while( ! (SPIM_Vectrex_Joy_2_ReadTxStatus() & SPIM_Vectrex_Joy_2_STS_BYTE_COMPLETE  ) );
    CyDelay(1);
}


void WaitForRxready_Vectrex()
{
    uint8 temp;
    while(!(temp &(SPIS_Vectrex_STS_RX_FIFO_NOT_EMPTY)))
    {
        temp = SPIS_Vectrex_ReadRxStatus();
    }
    while(SPIS_Vectrex_GetRxBufferSize() < 1);
}

void WaitForRxready()
{
    uint8 temp;
    while(!(temp &(SPIM_STS_RX_FIFO_NOT_EMPTY)))
    {
        temp = SPIM_ReadRxStatus();
    }
    while(SPIM_GetRxBufferSize() < 1);
}

uint8 WaitForAck()
{
    uint8 x = 0;
    uint8 z = 0;
    isr_cmp_Start();
    Timeout_SPIS = 0;
    Control_Reg_Count_Write(1);
    CyDelayUs(10);
    Control_Reg_Count_Write(0);
    while(Ack_Timeout == 0)
    {
        // check if isr happened
        if(Timeout_SPIS == 1)
        {
            z = 2;
            Timeout_SPIS = 0;
            break;
        }
    }
    isr_cmp_Stop();
    // check if we timed out waiting for ACK
    if(z == 2)
    {
        Lost_Comms = 1;     // flag that we lost comms with the controller
        LED_1_RED_Write(0);
        LED_2_RED_Write(0);
        LED_1_GREEN_Write(0);
        LED_2_GREEN_Write(0);
        for(x=0; x<4; x++)
        {
            LED_1_RED_Write(~LED_1_RED_Read());
            LED_2_RED_Write(~LED_2_RED_Read());
            CyDelay(250);
        }
        LED_1_RED_Write(0);
        LED_2_RED_Write(0);
        //SPIS_Vectrex_ClearRxBuffer();
        //SPIS_Vectrex_ClearFIFO();
        return 1;
    }
    Ack_Timeout = 0;
    //while(Acknowledge_Read() == 1);
    //while(Acknowledge_Read() == 0);
    return 0;   
}


// Here we squeeze down the min/max range of joy travel
// to translate down to +- 3.4V
// No longer used but kept here for historical reasons
uint8 MinMax(uint8 x)
{
    // Overall range from Joy
    const uint8 min = 0;
    const uint8 max = 255;
    // Desired range for UP joy motion
    const uint8 a_low = 39;
    const uint8 b_low = 127;
    // Desired range for DOWN joy motion
    const uint8 a_high = 128;
    const uint8 b_high = 217;
    float c;
    float d;
    uint8 f;
    // Check if middle of range
    if(x == b_low)
        return b_low;
    if(x == a_high)
        return a_high;
    // Check if joy is UP
    if(x < b_low)
    {
        c = (b_low - a_low)*(x-min);
        d = 127-min;
        f = (c/d)+a_low;
        return f;
    }
    // Otherwise joy is DOWN
    else
    {
        c = (b_high - a_high)*(x - 128);
        d = (max - 128);
        f = (c/d)+a_high;
        return f;
    }
   // Base formula:
   // c = (b-a)*(x-min);
   // d = max-min;
   // f = (c/d)+a;
   // return f;
}

void Get_Buttons()
{
    // Update button state
    // Logic high means button pressed
    //  Bit0 Bit1 Bit2 Bit3 Bit4 Bit5 Bit6 Bit7
    //  SLCT JOYR JOYL STRT UP   RGHT DOWN LEFT
    //  Bit8 Bit9 Bit10 Bit11 Bit12 Bit13 Bit14 Bit15
    //  L2   R2   L1    R1    /\    O     X     |_|
    Button_State = 0;
    Button_State = (uint16) controller.Button_1;
    Button_State = Button_State << 8;
    Button_State = Button_State | controller.Button_2;
    Button_State = ~Button_State;
}


void Handle_Buttons()
{
    // uint8 x = 0;
    static uint8 RapidFireState = 0;    // Bit Value:                 0  | 1 | 2 | 3 | 4
                                        // Button being held down:  None | 1 | 2 | 3 | 4
    
    // Get button states and process them
    // Handle Button 1
    if(Joy_Buttons.Button_1 & Button_State)
    {
        // Check for rapid fire select button 1
        if(Button_State & Select) {
            // Make sure not still holding buttons down
            if((RapidFireState & 1) == 0) {
                // Set or reset turbo fire button 1
                Control_Reg_Turbo_Fire_Write(Control_Reg_Turbo_Fire_Read() ^ 1);
            }
                RapidFireState |= 1;    // set button 1 rapid fire state bit
                return;
        }
        // Not in rapid fire mode, handle button press
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() & 14);
        RapidFireState &= 14;   // reset button 1 rapid fire state
    }
    // Button 1 wasn't pressed, make sure we reflect that
    else
    {
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() | 1);
        RapidFireState &= 14;
    }
    // Handle Button 2
    if(Joy_Buttons.Button_2 & Button_State)
    {
        // Check for rapid fire select button 2
        if(Button_State & Select) {
            // Make sure not still holding buttons down
            if((RapidFireState & 2) == 0) {
                // Set or reset turbo fire button 2
                Control_Reg_Turbo_Fire_Write(Control_Reg_Turbo_Fire_Read() ^ 2);
            }
                RapidFireState |= 2;    // set button 2 rapid fire state bit
                return;
        }
        // Not in rapid fire mode, handle button press
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() & 13);
        RapidFireState &= 13;   // reset button 1 rapid fire state
    }
    // Button 2 wasn't pressed, make sure we reflect that
    else
    {
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() | 2);
        RapidFireState &= 13;
    }
    // Handle Button 3
    if(Joy_Buttons.Button_3 & Button_State)
    {
        // Check for rapid fire select button 3
        if(Button_State & Select) {
            // Make sure not still holding buttons down
            if((RapidFireState & 4) == 0) {
                // Set or reset turbo fire button 3
                Control_Reg_Turbo_Fire_Write(Control_Reg_Turbo_Fire_Read() ^ 4);
            }
                RapidFireState |= 4;    // set button 2 rapid fire state bit
                return;
        }
        // Not in rapid fire mode, handle button press
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() & 11);
        RapidFireState &= 11;   // reset button 1 rapid fire state
    }
    // Button 2 wasn't pressed, make sure we reflect that
    else
    {
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() | 4);
        RapidFireState &= 11;
    }
    // Handle Button 4
    if(Joy_Buttons.Button_4 & Button_State)
    {
        // Check for rapid fire select button 4
        if(Button_State & Select) {
            // Make sure not still hloding buttons down
            if((RapidFireState & 8) == 0) {
                // Set or reset turbo fire button 4
                Control_Reg_Turbo_Fire_Write(Control_Reg_Turbo_Fire_Read() ^ 8);
            }
            RapidFireState |= 8;    // set button 4 rapid fire state bit
            return;
        }
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() & 7);
        RapidFireState &= 7;
    }
    else
    {
        Control_Reg_Joy_2_Buttons_Write(Control_Reg_Joy_2_Buttons_Read() | 8);
        RapidFireState &= 7;
    }
    // Handle Joy 2 Buttons
    if(Joy_Buttons.Button_5 & Button_State)
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() & 14);
    }
    else
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() | 1);
    }
    if(Joy_Buttons.Button_6 & Button_State)
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() & 13);
    }
    else
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() | 2);
    }
    if(Joy_Buttons.Button_7 & Button_State)
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() & 11);
    }
    else
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() | 4);
    }
    if(Joy_Buttons.Button_8 & Button_State)
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() & 7);
    }
    else
    {
        Control_Reg_Buttons_5_8_Write(Control_Reg_Buttons_5_8_Read() | 8);
    }
    if(Button_State & Joy_Left)
    {
        if(Button_State & Select)
        {
            // Reverse Joy Buttons
            Handle_Sticks(4);
            return;
        }
        else
        {
            Handle_Sticks(1);
            return;
        }
    }
    if(Button_State & Joy_Right)
    {
        Handle_Sticks(2);
        return;
    }
    if(Button_State & Start)
    {
        // Make sure no other buttons pressed
        if((Button_State & ~Start) == 0) {
            Program_Buttons();
            return;
        }
    }
    if(Button_State & Select)
    {
        // Robotron Mode
        // One controller / dual joysticks
        Handle_Sticks(3);
    }
}


uint8 Get_PS2_Data()
{
    
    uint8 Mode;
    uint8 temp;
    
    /* Clear the TX/RX buffers before next reading (good practice) */
    SPIM_ClearTxBuffer();
    SPIM_ClearRxBuffer();
    SPIM_Vectrex_Joy_ClearTxBuffer();
    // Attention low
    Control_Reg_SS_Write(0);
    CyDelay(2);
    // Write first command
    Write_To_SPI(0x01);
    // Wait for byte in RX buffer
    WaitForRxready();
    // Read byte from RX buffer
    Mode = SPIM_ReadByte();
    // Clear RX buffer
    SPIM_ClearRxBuffer();
    // Wait for Acknowledge from PS2 Controller
    WaitForAck();
    CyDelay(1);
        
    // Write second command
    Write_To_SPI(0x42);
    // Wait for byte in RX buffer
    WaitForRxready();
    // Read byte from RX buffer
    Mode = SPIM_ReadByte();
    // Clear RX buffer
    SPIM_ClearRxBuffer();
    // Wait for Acknowledge from PS2 Controller
    WaitForAck();
    CyDelay(1);
    
    switch (Mode)
    {
        // Check for analog mode
        case 0x73:
            // Get first byte (should be 5A)
            Write_To_SPI(0x00);
            WaitForRxready();
            temp = SPIM_ReadByte();
            WaitForAck();
            // CyDelay(1);
            CyDelayUs(10);  // was 500
            
            // Get buttons
            //  Bit0 Bit1 Bit2 Bit3 Bit4 Bit5 Bit6 Bit7
            //  SLCT JOYR JOYL STRT UP   RGHT DOWN LEFT
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Button_1 = SPIM_ReadByte();
            WaitForAck();
            //CyDelay(1);
            CyDelayUs(10);  // was 500
            
            // Get buttons
            //  Bit0 Bit1 Bit2 Bit3 Bit4 Bit5 Bit6 Bit7
            //  L2   R2   L1   R1   /\   O    X    |_|
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Button_2 = SPIM_ReadByte();
            WaitForAck();
            //CyDelay(1);
            CyDelayUs(10);  // was 500
            
            // Right Joy 0x00 = Left  0xFF = Right
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Joy_Right_LR = SPIM_ReadByte();
            WaitForAck();
            //CyDelay(1);
            CyDelayUs(10);
            
            // Right Joy 0x00 = Up    0xFF = Down
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Joy_Right_UD = SPIM_ReadByte();
            WaitForAck();
            //CyDelay(1);
            CyDelayUs(10);  // was 500
            
            // Left Joy  0x00 = Left  0xFF = Right
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Joy_Left_LR = SPIM_ReadByte();
            WaitForAck();
            //CyDelay(1);
            CyDelayUs(10);  // was 500
            
            // Left Joy  0x00 = Up    0xFF = Down
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Joy_left_UD = SPIM_ReadByte();
            // WaitForAck();
            CyDelay(1);
            break;
            
        // Check for digital mode
        case 0x41:
            // Get first byte (should be 5A)
            Write_To_SPI(0x00);
            WaitForRxready();
            temp = SPIM_ReadByte();
            WaitForAck();
            CyDelay(10);
            
            // Get buttons
            //  Bit0 Bit1 Bit2 Bit3 Bit4 Bit5 Bit6 Bit7
            //  SLCT JOYR JOYL STRT UP   RGHT DOWN LEFT
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Button_1 = SPIM_ReadByte();
            WaitForAck();
            CyDelay(10);
            
            // Get buttons
            //  Bit0 Bit1 Bit2 Bit3 Bit4 Bit5 Bit6 Bit7
            //  L2   R2   L1   R1   /\   O    X    |_|
            Write_To_SPI(0x00);
            WaitForRxready();
            controller.Button_2 = SPIM_ReadByte();
            WaitForAck();
            CyDelay(10);
            break;
        default:
            Mode = 0;
    }
    // Attention High
    Control_Reg_SS_Write(1);
    CyDelayUs(10);

    return Mode;
}

// Here when START is pressed
// 4 buttons can be programmed
// Press START again and back to original config
void Program_Buttons()
{
    uint8 x = 0;
    Button_State = 0;
    // Wait until START is released
    while(1)
    {
        Get_PS2_Data();
        Get_Buttons();
        if (Button_State == 0)
            break;
        CyDelay(10);
    }
    // Flash Amber LEDs twice to show entering button program mode
    LED_1_GREEN_Write(0);
    LED_2_GREEN_Write(0);
    for(x=0; x<4; x++) {
        LED_1_GREEN_Write(~LED_1_GREEN_Read());
        LED_2_GREEN_Write(~LED_2_GREEN_Read());
        LED_1_RED_Write(~LED_1_RED_Read());
        LED_2_RED_Write(~LED_2_RED_Read());
        Get_PS2_Data();
        CyDelay(500);
    }
    // Get the next 4 button presses and save them
    for(x=0; x < 8; x++)
    {
       // Button_Program_State = 1;    // Set programming state flag
        // Wait for a button press
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if(Button_State >0)
            {
                // make sure only legal buttons pressed
                if((Button_State & Start) == 0 && 
                   (Button_State & Select) == 0 &&
                   (Button_State & Joy_Left) ==  0 &&
                   (Button_State & Joy_Right) == 0) {
                    break;
                }
            }
            CyDelay(10);
        }
        // Record the new button config
        LED_1_GREEN_Write(0);
        LED_2_GREEN_Write(0);
        switch(x) {
            case 0:
                Joy_Buttons.Button_1 = Button_State;
                LED_1_GREEN_Write(1);
                break;
            case 1:
                Joy_Buttons.Button_2 = Button_State;
                LED_1_GREEN_Write(0);
                LED_1_RED_Write(1);
                break;
            case 2:
                Joy_Buttons.Button_3 = Button_State;
                LED_2_GREEN_Write(1);
                break;
            case 3:
                Joy_Buttons.Button_4 = Button_State;
                LED_2_GREEN_Write(0);
                LED_2_RED_Write(1);
                break;
            case 4:
                Joy_Buttons.Button_5 = Button_State;
                LED_1_RED_Write(0);
                LED_2_RED_Write(0);
                LED_1_GREEN_Write(1);
                LED_2_GREEN_Write(0);
                break;
            case 5:
                Joy_Buttons.Button_6 = Button_State;
                LED_1_GREEN_Write(0);
                LED_1_RED_Write(1);
                break;
            case 6:
                Joy_Buttons.Button_7 = Button_State;
                LED_2_GREEN_Write(1);
                break;
            case 7:
                Joy_Buttons.Button_8 = Button_State;
                LED_2_GREEN_Write(0);
                LED_2_RED_Write(1);
                break;
        }

        // Wait for button release
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    // Program button config in EEPROM
    EEPROM_1_UpdateTemperature();
    EEPROM_1_WriteByte(Joy_Buttons.Button_1 >> 8, 0);
    EEPROM_1_WriteByte(Joy_Buttons.Button_1,1);
    EEPROM_1_WriteByte(Joy_Buttons.Button_2 >> 8, 2);
    EEPROM_1_WriteByte(Joy_Buttons.Button_2,3);
    EEPROM_1_WriteByte(Joy_Buttons.Button_3 >> 8, 4);
    EEPROM_1_WriteByte(Joy_Buttons.Button_3,5);
    EEPROM_1_WriteByte(Joy_Buttons.Button_4 >> 8, 6);
    EEPROM_1_WriteByte(Joy_Buttons.Button_4,7);
    
    EEPROM_1_WriteByte(Joy_Buttons.Button_5 >> 8, 8);
    EEPROM_1_WriteByte(Joy_Buttons.Button_5,9);
    EEPROM_1_WriteByte(Joy_Buttons.Button_6 >> 8, 10);
    EEPROM_1_WriteByte(Joy_Buttons.Button_6,11);
    EEPROM_1_WriteByte(Joy_Buttons.Button_7 >> 8, 12);
    EEPROM_1_WriteByte(Joy_Buttons.Button_7,13);
    EEPROM_1_WriteByte(Joy_Buttons.Button_8 >> 8, 14);
    EEPROM_1_WriteByte(Joy_Buttons.Button_8,15);

    
    // Clear the LEDS
    CyDelay(250);
    LED_1_RED_Write(0);
    LED_2_RED_Write(0);
    LED_1_GREEN_Write(0);
    LED_2_GREEN_Write(1);
    // Flash altrnating Green LEDs four times to indicate programming complete
    for(x=0; x<8; x++) {
        LED_1_GREEN_Write(~LED_1_GREEN_Read());
        LED_2_GREEN_Write(~LED_2_GREEN_Read());
        Get_PS2_Data();
        CyDelay(250);
    }
    LED_1_GREEN_Write(0);
    LED_2_GREEN_Write(0);
}

// mode: [0 = handle joy] [1 = joy 0] [2 = joy 1] [3 = Controller robotron mode on] [4 = reverse joy]
//       [5 = robotron mode off] [6 = Vectrex robotron mode on]
void Handle_Sticks(uint8 mode)
{
    static uint8 buttonMode = 0;
    uint8 temp;
    uint8 temp_x;
    uint8 temp_y;
    uint8 temp_xx;
    uint8 temp_yy;
    static uint8 joy = 0;
    
    // Switch joy pots if requested
    if(buttonMode == 0) {   // Make sure not in Robotron mode
        if(mode == 1)
        {
            joy = 0;  // Left joy
        }
        if(mode == 2)
        {
            joy = 1;  // Right joy
        }
    }
    /*
    if(mode == 3)
    {
        if(buttonMode == 0) {
            joy = 2;    // Robotron mode
            buttonMode = 1; // set Robotron mode state
        }
        else {
            joy = 0;    // leaving Robotron mode
            buttonMode = 0;
        }
        // Wait until SELECT is released
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    */
    if(mode == 3)
    {
        if(buttonMode == 0) {
            joy = 2;    // Robotron mode
            buttonMode = 1; // set Robotron mode state
        }
        else {
            joy = 0;    // leaving Robotron mode
            buttonMode = 0;
        }
        // Wait until SELECT is released
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    if(mode == 4)
    {
        if(buttonMode == 1) {   // Make sure in Robotron mode
            if(joy == 2)
            {
                joy = 3; // reverse joysticks
            }
            else
            {
                joy = 2; // joysticks back to normal
            }
        }
        // Wait until buttons are released
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    if(mode == 5)
    {
        joy = 0;    // Robotron mode off
        buttonMode = 0;

        // Wait until SELECT is released
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    
    if(mode == 6)
    {
        joy = 2;    // Robotron mode on
        buttonMode = 1;

        // Wait until SELECT is released
        while(1)
        {
            Get_PS2_Data();
            Get_Buttons();
            if (Button_State == 0)
                break;
            CyDelay(10);
        }
    }
    
    LED_1_RED_Write(0);
    LED_2_RED_Write(0);
    switch(joy) {
        case 0:
            LED_1_GREEN_Write(1);
            LED_2_GREEN_Write(0);
            break;
        case 1:
            LED_1_GREEN_Write(0);
            LED_2_GREEN_Write(1);
            break;
        case 2:
            LED_1_GREEN_Write(1);
            LED_2_GREEN_Write(1);
            break;
        case 3:
            LED_1_GREEN_Write(1);
            LED_2_GREEN_Write(1);
            break;
    }
    temp = Get_PS2_Data();
    if(temp == 0x73)
    {
        // Send Joystick info to Vectrex
        // First force values to within min/max range
        switch (joy)
        {
            case 0:
                // temp_y = MinMax(controller.Joy_left_UD);
                temp_y = controller.Joy_left_UD;
                //temp_x = MinMax(controller.Joy_Left_LR);
                temp_x = controller.Joy_Left_LR;
                break;
            case 1:
                // temp_y = MinMax(controller.Joy_Right_UD);
                temp_y = controller.Joy_Right_UD;
                // temp_x = MinMax(controller.Joy_Right_LR);
                temp_x = controller.Joy_Right_LR;
                break;
            case 2:
                temp_y = controller.Joy_left_UD;    // left joystick
                temp_x = controller.Joy_Left_LR;
                temp_yy = controller.Joy_Right_UD;  // right joystick
                temp_xx = controller.Joy_Right_LR;
                break;
            case 3:
                temp_yy = controller.Joy_left_UD;    // right joystick
                temp_xx = controller.Joy_Left_LR;
                temp_y = controller.Joy_Right_UD;  // left joystick
                temp_x = controller.Joy_Right_LR;
                break;
        }
        // Select UP/Down digital pot and write value
        Control_Reg_Pot_CS_Write(2);
        Write_To_SPI_Pot(temp_y);
        // Select LF/RT digital pot and write value
        Control_Reg_Pot_CS_Write(1);
        Write_To_SPI_Pot(temp_x);
        Control_Reg_Pot_CS_Write(3);
        if(joy == 2 || joy == 3)
        {
            // Select UP/Down digital pot and write value
            Control_Reg_Pot_CS_Joy_2_Write(2);
            Write_To_SPI_Pot_Joy_2(temp_yy);
            // Select LF/RT digital pot and write value
            Control_Reg_Pot_CS_Joy_2_Write(1);
            Write_To_SPI_Pot_Joy_2(temp_xx);
            Control_Reg_Pot_CS_Joy_2_Write(3);
        }
        
    }
}

// flag = [0x01 = set analog] [0x00 = set digital]
void Setup_Controller(uint8 flag)
{
    uint8 Mode;
    
    /* Clear the TX/RX buffers before next reading (good practice) */
    SPIM_ClearTxBuffer();
    SPIM_ClearRxBuffer();
    Control_Reg_SS_Write(0);

    // Go into Configure Mode
    Write_To_SPI(0x01);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
        
    Write_To_SPI(0x43);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x01);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    
    Control_Reg_SS_Write(1);
    CyDelay(10);
    SPIM_ClearTxBuffer();
    SPIM_ClearRxBuffer();
    Control_Reg_SS_Write(0);
    
    // Turn on Analog mode and lock controller
    Write_To_SPI(0x01);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x44);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(flag);     // set the mode byte
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x03);     // lock controller (0x00 to give user control)
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    
    Control_Reg_SS_Write(1);
    CyDelay(10);
    SPIM_ClearTxBuffer();
    SPIM_ClearRxBuffer();
    Control_Reg_SS_Write(0);
    
    // Exit Config Mode
    Write_To_SPI(0x01);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
        
    Write_To_SPI(0x43);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x00);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x5a);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x5a);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x5a);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    Write_To_SPI(0x5a);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    if(WaitForAck() == 1)
    {
        return;
    }
    CyDelay(10);
    
    Write_To_SPI(0x5a);
    WaitForRxready();
    Mode = SPIM_ReadByte();
    SPIM_ClearRxBuffer();
    
    Control_Reg_SS_Write(1);
    CyDelay(10);
    SPIM_ClearTxBuffer();
    SPIM_ClearRxBuffer();
    //Control_Reg_SS_Write(0);
    Lost_Comms = 0;
}

void ZeroPots() {
    // Select UP/Down digital pot and write value
    Control_Reg_Pot_CS_Write(2);
    Write_To_SPI_Pot(128);
    CyDelay(10);
    // Select LF/RT digital pot and write value
    Control_Reg_Pot_CS_Write(1);
    Write_To_SPI_Pot(255);
    CyDelay(10);
    Control_Reg_Pot_CS_Write(3);

    // Select UP/Down digital pot and write value
    Control_Reg_Pot_CS_Joy_2_Write(2);
    Write_To_SPI_Pot_Joy_2(128);
    CyDelay(10);
    // Select LF/RT digital pot and write value
    Control_Reg_Pot_CS_Joy_2_Write(1);
    Write_To_SPI_Pot_Joy_2(128);
    CyDelay(10);
    Control_Reg_Pot_CS_Joy_2_Write(3);
    
}

void Reset_Buttons()
{
    Joy_Buttons.Button_1 = EEPROM_1_ReadByte(0) << 8;
    Joy_Buttons.Button_1 |= EEPROM_1_ReadByte(1);
    Joy_Buttons.Button_2 = EEPROM_1_ReadByte(2) << 8;
    Joy_Buttons.Button_2 |= EEPROM_1_ReadByte(3);
    Joy_Buttons.Button_3 = EEPROM_1_ReadByte(4) << 8;
    Joy_Buttons.Button_3 |= EEPROM_1_ReadByte(5);
    Joy_Buttons.Button_4 = EEPROM_1_ReadByte(6) << 8;
    Joy_Buttons.Button_4 |= EEPROM_1_ReadByte(7);
    Joy_Buttons.Button_5 = EEPROM_1_ReadByte(8) << 8;
    Joy_Buttons.Button_5 |= EEPROM_1_ReadByte(9);
    Joy_Buttons.Button_6 = EEPROM_1_ReadByte(10) << 8;
    Joy_Buttons.Button_6 |= EEPROM_1_ReadByte(11);
    Joy_Buttons.Button_7 = EEPROM_1_ReadByte(12) << 8;
    Joy_Buttons.Button_7 |= EEPROM_1_ReadByte(13);
    Joy_Buttons.Button_8 = EEPROM_1_ReadByte(14) << 8;
    Joy_Buttons.Button_8 |= EEPROM_1_ReadByte(15);
}


/*
void Flash_LED(uint8 count, uint8 speed)
{
    uint8 temp;
    uint8 state = 0x00;
    for(temp=0; temp < count; temp++)   // nummber flash cycles (x/2)
        {
            isr_flash_Start();
            while(1)
            {
                if(Flash_Count < speed)    // flash speed (x/1 sec)
                {
                    Setup_Controller(state);
                }
                else
                {
                    isr_flash_Stop();
                    Flash_Count = 0;
                    state = state ^ 1;
                    Control_Reg_SS_Write(1);
                    CyDelay(1);
                    SPIM_ClearTxBuffer();
                    SPIM_ClearRxBuffer();
                    // UART_1_PutChar(state);
                    break;
                }
            }
        }
        Setup_Controller(0x01);     // set analog mode
}
*/

void WaitForWrite()
{
  while( ! (SPIM_ReadTxStatus() & SPIM_STS_BYTE_COMPLETE  ) );
}

/*
------------------------------------------------------
Command: FE = Program buttons 
Data[4]:
        01=D-Up, 02=D-Right, 03=D-Down, 04=D-Left
        05=L2, 06=R2, 07=L1, 08=R1, 09=Triangle
        0A=Circle, 0B=X, 0C=Square
------------------------------------------------------
Command: FD = Turn on Robot Arena Mode 
------------------------------------------------------
Command: FC = Swap Joysticks in Robot Arena mode
-------------------------------------------------------
Command: FB = Turn off Robot Arena Mode 
-------------------------------------------------------

*/
void Handle_Vectrex_Data()
{
    uint8 SPIS_Data = 0;
    uint8 x = 0;
    uint8 y = 0;
    uint8 z = 0;
    // Get command
    SPIS_Data = SPIS_Vectrex_ReadByte();
    isr_cmp_Start();
    Timeout_SPIS = 0;
    // Handle command
    switch(SPIS_Data)
    {
        case 0xfe:
        for(x=0;x<4;x++)
            {
                Control_Reg_Count_Write(1);
                CyDelayUs(10);
                Control_Reg_Count_Write(0);
                z = 0;
                while(SPIS_Vectrex_GetRxBufferSize() == 0)
                {
                    // check if isr happened
                    if(Timeout_SPIS == 1)
                    {
                        z = 2;
                        Timeout_SPIS = 0;
                        break;
                    }
                }
                // check if we timed out waiting for data from Vectrex
                if(z == 2)
                {
                    Reset_Buttons();
                    LED_1_RED_Write(0);
                    LED_2_RED_Write(0);
                    LED_1_GREEN_Write(0);
                    LED_2_GREEN_Write(0);
                    for(x=0; x<4; x++)
                    {
                        LED_1_RED_Write(~LED_1_RED_Read());
                        LED_2_RED_Write(~LED_2_RED_Read());
                        CyDelay(250);
                    }
                    LED_1_RED_Write(0);
                    LED_2_RED_Write(0);
                    //SPIS_Vectrex_ClearRxBuffer();
                    //SPIS_Vectrex_ClearFIFO();
                    break;
                }
                SPIS_Data = SPIS_Vectrex_ReadByte();
                // check for valid button
                z = 0;
                for(y=0; y<(sizeof(LUT_Buttons)/sizeof(LUT_Buttons[0])); y++)
                {
                    if(SPIS_Data < (sizeof(LUT_Buttons)/sizeof(LUT_Buttons[0])))
                    {
                        // the button is valid
                        z = 1;
                    }
                }
                if(z == 1)
                {
                    switch(x)
                    {
                        case 0:
                        Joy_Buttons.Button_1 = LUT_Buttons[SPIS_Data];
                        break;
                        
                        case 01:
                        Joy_Buttons.Button_2 = LUT_Buttons[SPIS_Data];
                        break;
                        
                        case 02:
                        Joy_Buttons.Button_3 = LUT_Buttons[SPIS_Data];
                        break;
                        
                        case 03:
                        Joy_Buttons.Button_4 = LUT_Buttons[SPIS_Data];
                        LED_1_RED_Write(0);
                        LED_2_RED_Write(0);
                        LED_1_GREEN_Write(0);
                        LED_2_GREEN_Write(1);
                        // Flash altrnating Green LEDs four times to indicate programming complete
                        for(x=0; x<8; x++) {
                            LED_1_GREEN_Write(~LED_1_GREEN_Read());
                            LED_2_GREEN_Write(~LED_2_GREEN_Read());
                            Get_PS2_Data();
                            CyDelay(250);
                        }
                        LED_1_GREEN_Write(0);
                        LED_2_GREEN_Write(0);
                        //SPIS_Vectrex_ClearRxBuffer();
                        //SPIS_Vectrex_ClearFIFO();
                        break;
                    }
                }
                else
                {
                    // Invalid button sent from Vec, reset buttons
                    isr_cmp_Stop();
                    Reset_Buttons();
                    LED_1_RED_Write(0);
                    LED_2_RED_Write(0);
                    LED_1_GREEN_Write(0);
                    LED_2_GREEN_Write(0);
                    for(x=0; x<2; x++)
                    {
                        LED_1_RED_Write(~LED_1_RED_Read());
                        LED_2_RED_Write(~LED_2_RED_Read());
                        CyDelay(250);
                    }
                    LED_1_RED_Write(0);
                    LED_2_RED_Write(0);
                    //SPIS_Vectrex_ClearRxBuffer();
                    //SPIS_Vectrex_ClearFIFO();
                    break;
                }
            }
            break;
        
        case 0xfd:
        // turn on robot arena mode
        Handle_Sticks(6);
        break;
        
        case 0xfc:
        // reverse joysticks in robot arena mode
        Handle_Sticks(4);
        break;
        
        case 0xfb:
        // turn off robot arena mode
        Handle_Sticks(5);
        break;
        
        default:
        isr_cmp_Stop();
        //SPIS_Vectrex_ClearRxBuffer();
        //SPIS_Vectrex_ClearFIFO();
        return;
    }
}

/* [] END OF FILE */
