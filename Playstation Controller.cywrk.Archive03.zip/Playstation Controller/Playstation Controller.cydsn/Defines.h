/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define BitTest(Var, Pos)  ((Var) & (1 << (Pos)))

// Button_1 Bit Masks
#define Select      0x0100    //0xfe
#define Joy_Left    0x0200    //0xfd
#define Joy_Right   0x0400    //0xfb
#define Start       0x0800    //0xf7
#define Pad_Up      0x1000    //0xef
#define Pad_Right   0x2000    //0xdf
#define Pad_Down    0x4000    //0xbf
#define Pad_Left    0x8000    //0x7f

// Button_2 Bit Masks
#define L2          0x0001    //0xfe
#define R2          0x0002    //0xfd
#define L1          0x0004    //0xfb
#define R1          0x0008    //0xf7
#define Triangle    0x0010    //0xef
#define Circle      0x0020    //0xdf
#define X           0x0040    //0xbf
#define Square      0x0080    //0x7f


/* [] END OF FILE */
